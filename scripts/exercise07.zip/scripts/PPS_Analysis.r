#################################################
#                                               #
# Analysis for Posterior Predictive Simulations #
#                                               #
################################################# 


## Set your working directory
setwd("Desktop/FAU/Lectures/phylogenetics/Model Adequacy Tutorial/")

## Some variables to help with the analysis
mod <- list.files("output/")
mod <- as.data.frame(mod)
empfilename <- "empirical_inference_model_adequacy.csv"
simfilename <- "simulated_inference_model_adequacy.csv"

## Create a dataframe to hold the results from the test statistics
testz <- c("Box_TL", "Box_RF", "Box_CI", "Box_RI")
outputfilenames <- matrix(ncol=length(mod$mod), nrow=length(testz))
colnames(outputfilenames) <- mod$mod
rownames(outputfilenames) <- testz

## You can load any empirical output file here. It's just to get the names of the test
## statistics used 
emp <- read.csv(paste0("output/mk/results/empirical_inference_model_adequacy.csv"))
test <- names(emp)

## create a directory for the new figures 
dir.create("Figures")


## create a pdf for histograms for Tree Length and Robinson Foulds
pdf(paste0("Figures/Histrograms.pdf"))
par(mfrow=c(2,2))

## Tree Length
i=2
for (k in 1:length(mod$mod)){ 
  
  simname <- paste0("output/",mod[k,], "/results/" , simfilename)
  empname <- paste0("output/",mod[k,], "/results/" , empfilename )
  sim <- read.csv(simname)
  emp <- read.csv(empname)

  s = i +1
  hist(sim[,s], col = "white", main = paste0(mod[k,]), xlab = "", xlim=c(1,2.5))
  abline(v=emp[,i], lwd=4, lty =1, col = "dodgerblue")
  abline(v=median(sim[,s]), lwd=4, lty =2, col = "plum")
  
  
}
mtext("Tree Length", outer=TRUE,  cex=1, line=-1.5)

## Robinson Foulds
i=1
for (k in 1:length(mod$mod)){ 
  
  simname <- paste0("output/",mod[k,], "/results/", simfilename)
  empname <- paste0("output/",mod[k,], "/results/", empfilename)
  sim <- read.csv(simname)
  emp <- read.csv(empname)
  s = i +1
  hist(sim[,s], col = "white", main = paste0(mod[k,]), xlab = "", xlim=c(0,8))
  abline(v=emp[,i], lwd=4, lty =1, col = "dodgerblue")
  abline(v=median(sim[,s]), lwd=4, lty =2, col = "plum")
  
}
mtext("Robinson Foulds", line = 3, adj = -4.5)
dev.off()



## Create a pdf for boxplots
pdf("Figures/Boxplots.pdf")
par(mfrow=c(2,2))

## Tree Length
final <- matrix(nrow = length(sim$simID), ncol=length(mod$mod))
colnames(final) <- mod$mod
for (k in 1:length(mod$mod)){
  
  simname <- paste0("output/",mod[k,], "/results/" , simfilename)
  empname <- paste0("output/",mod[k,], "/results/", empfilename)
  sim <- read.csv(simname)
  emp <- read.csv(empname)
  std <- sd(sim$mean_tl)
  
  for (i in 1:length(sim$simID)){
    numsim <- sim$mean_tl[i]
    final[i,mod[k,]] <- (emp$mean_tl - numsim) / std
  }
  
  
}

mods <- stack(as.data.frame(final))


x <- boxplot(mods$values ~ mods$ind, lty=1, main="Tree Length")
abline(h=0, lty = 2)
for (m in 1:length(mod$mod)){
  
  outputfilenames["Box_TL", mod[m,]] <- x$stats[3,m]
}

## Robinson Foulds
final <- matrix(nrow = length(sim$simID), ncol=length(mod$mod))
colnames(final) <- mod$mod
for (k in 1:length(mod$mod)){
  
  simname <- paste0("output/",mod[k,], "/results/", simfilename)
  empname <- paste0("output/",mod[k,], "/results/", empfilename)
  sim <- read.csv(simname)
  emp <- read.csv(empname)
  std <- sd(sim$mean_rf)
  
  for (i in 1:length(sim$simID)){
    numsim <- sim$mean_rf[i]
    final[i,mod[k,]] <- (emp$mean_rf - numsim) / std
  }
}

mods <- stack(as.data.frame(final))
x <- boxplot(mods$values ~ mods$ind, lty=1, main="Robinson Foulds")
abline(h=0, lty = 2)
for (m in 1:length(mod$mod)){
  
  outputfilenames["Box_RF", mod[m,]] <- x$stats[3,m]
}

## Consistency Index & Retenetion Index
for (n in 1:2){
  
  loopname <- "output/mk/output/model_adequacy_post_sims/"
  loop <- list.files(loopname)
  
  empdata <- ape::read.nexus.data("data/Agnolin_2007a_paleobiodb.nex")
  models <- matrix(nrow=length(loop), ncol=length(mod$mod))
  colnames(models) <- mod$mod
  for (k in 1:length(mod$mod)){
    
    loopname <- paste0("output/",mod[k,], "/output/model_adequacy_post_sims/")
    loop <- list.files(loopname)
    
    empname <- paste0("output/",mod[k,] ,"/output/model_adequacymcc.tre" )
    emp1 <- ape::read.nexus(empname)
    empd <-  phangorn::phyDat(empdata, type="USER", levels=c("0","1","2","3"), return.index = TRUE)
    
    if (n == 1){
      empci <- phangorn::CI(emp1, empd)
    }
    
    else {
      empci <- phangorn::RI(emp1, empd)
    }
    
    ConInd <- matrix(nrow=length(loop), ncol = 2)
    colnames(ConInd) <- c("RI" , "dist")
    for (i in 1:length(loop)){
      file <- paste0(loopname , loop[i] , "/seq.nex")
      simdata <- ape::read.nexus.data(file)
      simd <-  phangorn::phyDat(simdata, type="USER", levels=c("0","1","2","3"), return.index = TRUE)
      
      if (n ==1 ){
        ConInd[i,1] <- phangorn::CI(emp1, simd)
      }
      else {
        ConInd[i,1] <- phangorn::RI(emp1, simd) 
      }
      
    }
    
    standdev <- sd(ConInd[,1])
      for (j in 1:length(loop)){
      
      ConInd[j,2] <- (empci - ConInd[j,1] )/ standdev
      
    }
    
    models[,mod[k,]] <- ConInd[,2]
    
  }
  if (n == 1 ){
    mods <- stack(as.data.frame(models))
    x <- boxplot(mods$values ~ mods$ind, lty=1,  main = "Consistency Index")
    abline(h=0, lty = 2)
  } else {
    mods <- stack(as.data.frame(models))
    x <- boxplot(mods$values ~ mods$ind, lty=1,  main = "Retention Index")
    abline(h=0, lty = 2)
  }
  
  
  for (m in 1:length(mod$mod)){
    if (n ==1){
      outputfilenames["Box_CI", mod[m,]] <- x$stats[3,m]
    } else {
      outputfilenames["Box_RI", mod[m,]] <- x$stats[3,m]
    }
  }
  
  
}

dev.off()
outputfilenames <- as.data.frame(outputfilenames)

outputfilenames["Total",] <- 0

for (m in 1:length(mod$mod)){
  outputfilenames["Total",m] <- sum(abs(outputfilenames[1:4,mod[m,]]))
}

write.csv(outputfilenames, paste0("Figures/results.csv"))







